---
title: "Read me"
layout: default
permalink: /about/
layout: single
---

![image](https://user-images.githubusercontent.com/42318591/83466182-46ab0080-a4b1-11ea-9736-5841d57e0518.png){: width="40%" height="40%"}{: .align-center}

✉ bboddak@gmaill.com
{: style="text-align: center;"}

개인적으로 공부하고 프로젝트 한 것들을 기록하는 블로그입니다.  
저만의 위키 혹은 포트폴리오와도 같은 소중한 공간이에요! 👱‍♀️  
{: style="text-align: center;"}
{: .notice--warning}

<!--
이 블로그의 모든 글들은 검색 엔진에 노출되지 않습니다. [📜robots.txt](https://ansohxxn.github.io/robots.txt)
-->